- Upgrade to 2.37
    - Popup code
    - Script into run
    - Resume game code
- delete Open Dyslexic
- Update Settings
- Update credits
- Have a regular page without the stats bar (for peeps who don't need it)
-> #textbloc should be transfered to #passages

Mobile: visibility: hidden; -> visiblity in mobile

CSS:
    #menu -> #left-menu
    #bars -> #right-menu
    #mobile-bars -> #mobile-top-menu
    #mobile-menu -> #mobile-btm-menu
    #textbloc -> gone, transfer to #passages